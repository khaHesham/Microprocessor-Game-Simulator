## Download DOSbox from the link below

[Sourceforge](https://sourceforge.net/projects/dosbox/)

## Create a folder in your C drive
Download this repo, extract it and paste all the all files in your newly created folder.

## Open DOSbox .cong file and write the following code at very bottom of the conf file for automatic mount on every launch.

```text
mount c c:\folder_name
c:
```
